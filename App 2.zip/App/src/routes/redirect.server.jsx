export default function Redirect({response}) {
  return response.redirect('/products/snowboard');
}
