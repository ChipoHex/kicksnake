module.exports = {
  extends: ['plugin:hydrogen/recommended'],
};
